<?php
// ============================================================
// LAST HUMAN INPUT — GET /api/get_decision.php?id=N
// Returns a single decision's full record
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    jsonError('A valid decision ID is required.', 400);
}

$db   = getDB();
$stmt = $db->prepare("SELECT * FROM decisions WHERE id = :id LIMIT 1");
$stmt->execute([':id' => $id]);
$decision = $stmt->fetch();

if (!$decision) {
    jsonError('Decision not found.', 404);
}

echo json_encode(['success' => true, 'decision' => $decision]);
