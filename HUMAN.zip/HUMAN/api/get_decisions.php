<?php
// ============================================================
// LAST HUMAN INPUT — GET /api/get_decisions.php
// Returns all decisions ordered by newest first
// ============================================================

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../config.php';

$db   = getDB();
$stmt = $db->query("
    SELECT id, title, domain, created_at
    FROM decisions
    ORDER BY created_at DESC
");
$decisions = $stmt->fetchAll();

echo json_encode(['success' => true, 'decisions' => $decisions]);
