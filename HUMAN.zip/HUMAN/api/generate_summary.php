<?php
// ============================================================
// LAST HUMAN INPUT — GET /api/generate_summary.php?id=N
// Generates the Gemini AI summary for a decision that
// doesn't have one yet, then stores and returns it.
// Called by the detail page after it renders.
// ============================================================

ini_set('display_errors', '0');
error_reporting(0);
set_time_limit(60);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../gemini.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    jsonError('A valid decision ID is required.');
}

try {
    $db   = getDB();
    $stmt = $db->prepare("SELECT * FROM decisions WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $id]);
    $decision = $stmt->fetch();
} catch (Exception $e) {
    jsonError('Database error: ' . $e->getMessage(), 500);
}

if (!$decision) {
    jsonError('Decision not found.', 404);
}

// If summary already exists, return it immediately
if (!empty($decision['ai_summary'])) {
    jsonSuccess(['summary' => $decision['ai_summary'], 'already_existed' => true]);
}

// Generate the summary
$fields = [
    'title'                  => $decision['title'],
    'domain'                 => $decision['domain'],
    'automation_description' => $decision['automation_description'],
    'goal'                   => $decision['goal'],
    'assumptions'            => $decision['assumptions'],
    'risks'                  => $decision['risks'],
];

$decisionText = composeDecisionText($fields);
$aiSummary    = getGeminiSummary($decisionText);

// Store it
try {
    $upd = $db->prepare("UPDATE decisions SET ai_summary = :summary WHERE id = :id");
    $upd->execute([':summary' => $aiSummary, ':id' => $id]);
} catch (Exception $e) {
    // Already have the summary text; return it even if the update failed
}

jsonSuccess(['summary' => $aiSummary]);
