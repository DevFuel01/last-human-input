<?php
// ============================================================
// LAST HUMAN INPUT — POST /api/log_decision.php
// ONLY saves the decision to DB. Returns the new ID immediately.
// AI summary is generated separately by generate_summary.php.
// ============================================================

ini_set('display_errors', '0');
error_reporting(0);

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);

if (!$data) {
    jsonError('Invalid JSON body.');
}

$required = ['title', 'domain', 'automation_description', 'goal', 'assumptions', 'risks'];
foreach ($required as $field) {
    if (empty(trim($data[$field] ?? ''))) {
        jsonError("Missing required field: {$field}");
    }
}

$isAnonymous = !empty($data['is_anonymous']) ? 1 : 0;
$humanName   = $isAnonymous ? 'Anonymous' : trim($data['human_name'] ?? '');
if (!$isAnonymous && empty($humanName)) {
    jsonError('Please provide your name or check the Anonymous box.');
}

try {
    $db   = getDB();
    $stmt = $db->prepare("
        INSERT INTO decisions
            (title, domain, automation_description, goal, assumptions, risks, human_name, is_anonymous)
        VALUES
            (:title, :domain, :automation_description, :goal, :assumptions, :risks, :human_name, :is_anonymous)
    ");
    $stmt->execute([
        ':title'                  => trim($data['title']),
        ':domain'                 => trim($data['domain']),
        ':automation_description' => trim($data['automation_description']),
        ':goal'                   => trim($data['goal']),
        ':assumptions'            => trim($data['assumptions']),
        ':risks'                  => trim($data['risks']),
        ':human_name'             => $humanName,
        ':is_anonymous'           => $isAnonymous,
    ]);
    $newId = (int) $db->lastInsertId();
} catch (Exception $e) {
    jsonError('Database error: ' . $e->getMessage(), 500);
}

jsonSuccess(['id' => $newId]);
