-- Run this to update the 3 seed decisions with structured AI summaries
USE last_human_input;

UPDATE decisions SET ai_summary =
'[SUMMARY]
The decision-maker aims to scale hiring operations by delegating initial candidate evaluation to a machine learning model, reducing manual effort and processing time. The system will screen all incoming applications before any human reviewer sees them. Candidates who score below a defined threshold are removed from consideration without review. The core objective is operational efficiency in a high-volume recruitment environment.
[/SUMMARY]

[ASSUMPTIONS]
The model''s training data — derived from five years of past hiring decisions — reflects outcomes that represent desirable future hires. The algorithm is assumed to evaluate candidate potential more consistently than time-pressured human reviewers. The threshold score is assumed to be a technically valid cutoff rather than an arbitrary value with significant consequences.
[/ASSUMPTIONS]

[RISKS]
If past hiring skewed toward specific universities, demographics, or backgrounds, the model will systematically reproduce those patterns at scale. Qualified candidates from non-traditional paths may be excluded without any human ever reviewing their application. The threshold score transforms a subjective human judgment into an automated gate that affected candidates cannot observe, contest, or appeal.
[/RISKS]'
WHERE title = 'Automated Resume Screening for Engineering Roles';

UPDATE decisions SET ai_summary =
'[SUMMARY]
The decision-maker intends to deploy an AI triage assistant to address emergency department capacity and consistency challenges, with nurses retaining formal override authority. The system will present an algorithmic priority rating before the nurse completes their own assessment. The goal is to reduce cognitive load during surge conditions and decrease variability in triage outcomes across shifts and staff.
[/SUMMARY]

[ASSUMPTIONS]
The AI model''s accuracy on its training data is assumed to generalize to this hospital''s patient population, including regional demographics and presentation patterns. Nurses are assumed to exercise independent clinical judgment despite seeing the AI recommendation first. The system is assumed to be most helpful in routine cases, while human skill compensates for edge cases where the model is weakest.
[/ASSUMPTIONS]

[RISKS]
Automation bias poses the primary risk: nurses may defer to algorithmic recommendations rather than exercise independent judgment, particularly under cognitive load — reducing the effective human oversight the system claims to retain. Patients who present atypically are the highest-stakes cases and the ones where the model is least reliable. If the training data does not reflect this hospital''s patient demographics, systematic misclassification may occur for specific populations. The accountability structure for AI-influenced triage decisions that result in adverse outcomes has not been defined.
[/RISKS]'
WHERE title = 'AI Triage Priority Assignment in Emergency Department';

UPDATE decisions SET ai_summary =
'[SUMMARY]
The decision-maker seeks to automate personal loan underwriting for applications below $25,000, removing human review from the decision path entirely. Approvals and declines are generated algorithmically within seconds, with no underwriter involved at any stage. The stated objectives are cost reduction, processing speed, and decision consistency at scale.
[/SUMMARY]

[ASSUMPTIONS]
Historical financial behavior captured in available data is assumed to constitute a legally sound and accurate predictor of future repayment ability across the full applicant population. The model is assumed to generalize to future applicants in the same way it performed on historical data. Declined applicants are assumed to have alternative credit options, reducing the consequence of a false rejection.
[/ASSUMPTIONS]

[RISKS]
Thin-file applicants — including young people, recent immigrants, and those outside formal banking systems — may be systematically excluded not due to elevated risk, but due to data absence. Behavioral signals may correlate with protected characteristics without explicitly encoding them, creating fair lending regulatory exposure. Declined applicants receive no meaningful explanation and have no appeal path in the current design. If the model''s assumptions break down during economic conditions not represented in training data, it may produce correlated failures at scale before any human reviewer identifies the pattern.
[/RISKS]'
WHERE title = 'Algorithmic Credit Scoring for Personal Loan Applications';

SELECT id, title, LEFT(ai_summary, 60) AS summary_preview FROM decisions;
