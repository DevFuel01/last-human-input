-- LAST HUMAN INPUT
-- Database Schema & Seed Data
-- Run this in phpMyAdmin or via MySQL CLI

CREATE DATABASE IF NOT EXISTS last_human_input CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE last_human_input;

CREATE TABLE IF NOT EXISTS decisions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    domain ENUM('Healthcare','Finance','Hiring','Education','Justice','Governance','Other') NOT NULL,
    automation_description TEXT,
    goal TEXT,
    assumptions TEXT,
    risks TEXT,
    human_name VARCHAR(255),
    is_anonymous TINYINT(1) DEFAULT 0,
    ai_summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Data: Three example decisions
-- AI summaries use structured [SUMMARY][ASSUMPTIONS][RISKS] format

TRUNCATE TABLE decisions;

INSERT INTO decisions (title, domain, automation_description, goal, assumptions, risks, human_name, is_anonymous, ai_summary, created_at)
VALUES (
    'Automated Resume Screening for Engineering Roles',
    'Hiring',
    'We are deploying a machine learning model trained on 5 years of past hiring decisions to automatically rank and filter job applicants before any human reviews them. Candidates below a threshold score will not proceed to interviews.',
    'Reduce recruiter workload by 60% and decrease time-to-hire from 45 days to 15 days. Handle the increased volume of applications without expanding the HR team.',
    'The model''s training data reflects good hiring outcomes. Past hired employees represent the kind of talent we want. The algorithm can objectively evaluate potential better than overloaded recruiters doing quick reads.',
    'The training data may encode historical bias — if past hires skewed toward certain universities or demographics, the model will replicate that. Qualified candidates from non-traditional backgrounds may be systematically excluded without anyone noticing. The threshold score is a human judgment call dressed as a mathematical fact.',
    'D. Okonkwo',
    0,
    '[SUMMARY]
The decision-maker aims to scale hiring operations by delegating initial candidate evaluation to a machine learning model, reducing manual effort and processing time. The system will screen all incoming applications before any human reviewer sees them. Candidates who score below a defined threshold are removed from consideration without review. The core objective is operational efficiency in a high-volume recruitment environment.
[/SUMMARY]

[ASSUMPTIONS]
The model''s training data — derived from five years of past hiring decisions — reflects outcomes that represent desirable future hires. The algorithm is assumed to evaluate candidate potential more consistently than time-pressured human reviewers. The threshold score is assumed to be a technically valid cutoff rather than an arbitrary value with significant consequences.
[/ASSUMPTIONS]

[RISKS]
If past hiring skewed toward specific universities, demographics, or backgrounds, the model will systematically reproduce those patterns at scale. Qualified candidates from non-traditional paths may be excluded without any human ever reviewing their application. The threshold score transforms a subjective human judgment into an automated gate that affected candidates cannot observe, contest, or appeal.
[/RISKS]',
    '2026-01-14 09:22:00'
),
(
    'AI Triage Priority Assignment in Emergency Department',
    'Healthcare',
    'A clinical AI tool will be integrated into the emergency department intake process. The system will analyze patient-reported symptoms, vital signs, and medical history to assign a triage priority level (1–5) that determines waiting time and care urgency. Nurses will see the AI recommendation before making their own assessment.',
    'Reduce patient wait times during peak hours. Improve consistency in triage decisions across shifts and reduce the cognitive load on nursing staff during surge events.',
    'The AI model, trained on clinical datasets, performs at or above average nurse-level accuracy for triage classification. Nurses will still review AI suggestions and can override. The system will improve outcomes for the average case while freeing nursing attention for complex cases.',
    'The training data may not reflect our patient population — regional demographics, common conditions, and language barriers differ across hospitals. AI suggestions may anchor nurse judgment, creating automation bias where nurses defer to the system rather than exercise independent clinical reasoning. Edge cases — patients who present atypically — are exactly the cases where AI is least reliable and stakes are highest. System failures during high-demand periods could cause cascading delays.',
    'Dr. M. Ferreira',
    0,
    '[SUMMARY]
The decision-maker intends to deploy an AI triage assistant to address emergency department capacity and consistency challenges, with nurses retaining formal override authority. The system will present an algorithmic priority rating before the nurse completes their own assessment. The goal is to reduce cognitive load during surge conditions and decrease variability in triage outcomes across shifts and staff.
[/SUMMARY]

[ASSUMPTIONS]
The AI model''s accuracy on its training data is assumed to generalize to this hospital''s patient population, including regional demographics and presentation patterns. Nurses are assumed to exercise independent clinical judgment despite seeing the AI recommendation first. The system is assumed to be most helpful in routine cases, while human skill compensates for edge cases where the model is weakest.
[/ASSUMPTIONS]

[RISKS]
Automation bias poses the primary risk: nurses may defer to algorithmic recommendations rather than exercise independent judgment, particularly under cognitive load — reducing the effective human oversight the system claims to retain. Patients who present atypically are the highest-stakes cases and the ones where the model is least reliable. If the training data does not reflect this hospital''s patient demographics, systematic misclassification may occur for specific populations. The accountability structure for AI-influenced triage decisions that result in adverse outcomes has not been defined.
[/RISKS]',
    '2026-01-28 14:05:00'
),
(
    'Algorithmic Credit Scoring for Personal Loan Applications',
    'Finance',
    'We are replacing manual underwriter review with an automated credit decisioning system for personal loan applications under $25,000. The system uses credit bureau data, transaction history, employment records, and behavioral signals to generate an approval decision within seconds. Applications that score below the cutoff are automatically declined without human review.',
    'Eliminate underwriting bottlenecks, reduce origination costs by 40%, enable 24/7 loan processing, and standardize decisions to reduce inconsistency between individual underwriters.',
    'The approved variables are legally permissible proxies for creditworthiness. Automated decisions are more consistent and less subject to individual bias than human underwriters. Customers who are declined have other lending options. The model will generalize well to future applicants similar to our historical applicants.',
    'Thin-file applicants — young people, recent immigrants, or those who avoid formal banking — may be systematically excluded not because they are high-risk, but because the model lacks data on them. Behavioral signals may correlate with protected characteristics without explicitly using them, creating fair lending exposure. Declined applicants receive no meaningful explanation. There is no appeal path in the current design. If the model''s assumptions break down during an economic shock, it may produce systematically wrong decisions at scale before any human notices.',
    'Anonymous',
    1,
    '[SUMMARY]
The decision-maker seeks to automate personal loan underwriting for applications below $25,000, removing human review from the decision path entirely. Approvals and declines are generated algorithmically within seconds, with no underwriter involved at any stage. The stated objectives are cost reduction, processing speed, and decision consistency at scale.
[/SUMMARY]

[ASSUMPTIONS]
Historical financial behavior captured in available data is assumed to constitute a legally sound and accurate predictor of future repayment ability across the full applicant population. The model is assumed to generalize to future applicants in the same way it performed on historical data. Declined applicants are assumed to have alternative credit options, reducing the consequence of a false rejection.
[/ASSUMPTIONS]

[RISKS]
Thin-file applicants — including young people, recent immigrants, and those outside formal banking systems — may be systematically excluded not due to elevated risk, but due to data absence. Behavioral signals may correlate with protected characteristics without explicitly encoding them, creating fair lending regulatory exposure. Declined applicants receive no meaningful explanation and have no appeal path in the current design. If the model''s assumptions break down during economic conditions not represented in training data, it may produce correlated failures at scale before any human reviewer identifies the pattern.
[/RISKS]',
    '2026-02-03 11:47:00'
);
