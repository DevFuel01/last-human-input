// ============================================================
// LAST HUMAN INPUT — Shared Utilities (app.js)
// ============================================================

const API = {
  LOG:      'api/log_decision.php',
  LIST:     'api/get_decisions.php',
  DETAIL:   'api/get_decision.php',
};

/**
 * Get query param from current URL
 */
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/**
 * Format a date string to readable form
 * e.g. "2026-01-14 09:22:00" → "14 January 2026"
 */
function formatDate(dateStr) {
  const d = new Date(dateStr.replace(' ', 'T'));
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}

/**
 * Escape HTML entities to prevent XSS
 */
function esc(str) {
  const d = document.createElement('div');
  d.textContent = str || '';
  return d.innerHTML;
}

/**
 * Show an alert banner inside a container element
 */
function showAlert(containerId, message, type = 'error') {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `<div class="alert alert--${type}">${esc(message)}</div>`;
}

/**
 * Clear an alert container
 */
function clearAlert(containerId) {
  const el = document.getElementById(containerId);
  if (el) el.innerHTML = '';
}

/**
 * POST JSON to an endpoint
 */
async function postJSON(url, data) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

/**
 * GET JSON from an endpoint
 */
async function getJSON(url) {
  const res = await fetch(url);
  return res.json();
}
