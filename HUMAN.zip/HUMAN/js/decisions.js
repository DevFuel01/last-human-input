// ============================================================
// LAST HUMAN INPUT — Decision List (decisions.js)
// ============================================================

(async function () {
  const container = document.getElementById('decisions-container');

  try {
    const data = await getJSON(API.LIST);

    if (!data.success || !data.decisions) {
      container.innerHTML = `<div class="state-box state-box--error">Failed to load decisions. Please try again.</div>`;
      return;
    }

    const decisions = data.decisions;

    if (decisions.length === 0) {
      container.innerHTML = `
        <div class="state-box">
          <p>No decisions have been logged yet.</p>
          <a href="log.html" class="btn btn--outline" style="margin-top:1rem; display:inline-flex;">Be the first to log a decision</a>
        </div>`;
      return;
    }

    const html = `
      <div class="card-list">
        ${decisions.map(d => `
          <a class="card card--link" href="detail.html?id=${encodeURIComponent(d.id)}" id="decision-${d.id}">
            <div class="card__meta" style="margin-bottom:0.5rem;">
              <span class="badge">${esc(d.domain)}</span>
              <span class="date-str">${formatDate(d.created_at)}</span>
            </div>
            <div class="card__title">${esc(d.title)}</div>
          </a>
        `).join('')}
      </div>
      <p style="font-size:0.8rem; color:var(--ink-faint); margin-top:1.5rem; text-align:right;">
        ${decisions.length} decision${decisions.length === 1 ? '' : 's'} on record
      </p>
    `;

    container.innerHTML = html;

  } catch (err) {
    container.innerHTML = `<div class="state-box state-box--error">Network error: ${esc(err.message)}</div>`;
  }
})();
