// ============================================================
// LAST HUMAN INPUT — Form Submission (log.js)
// ============================================================

(function () {
  const form      = document.getElementById('decision-form');
  const submitBtn = document.getElementById('submit-btn');
  const statusEl  = document.getElementById('submit-status');
  const anonBox   = document.getElementById('is_anonymous');
  const nameInput = document.getElementById('human_name');

  // Toggle name field based on anonymous checkbox
  anonBox.addEventListener('change', function () {
    nameInput.disabled = this.checked;
    nameInput.value    = this.checked ? '' : nameInput.value;
    if (this.checked) nameInput.style.opacity = '0.45';
    else              nameInput.style.opacity = '1';
  });

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    clearAlert('form-alert');

    // Collect values
    const fields = {
      title:                  form.title.value.trim(),
      domain:                 form.domain.value,
      automation_description: form.automation_description.value.trim(),
      goal:                   form.goal.value.trim(),
      assumptions:            form.assumptions.value.trim(),
      risks:                  form.risks.value.trim(),
      human_name:             nameInput.value.trim(),
      is_anonymous:           anonBox.checked ? 1 : 0,
    };

    // Client-side validation
    const required = ['title', 'domain', 'automation_description', 'goal', 'assumptions', 'risks'];
    for (const key of required) {
      if (!fields[key]) {
        showAlert('form-alert', 'Please fill in all required fields before submitting.');
        document.getElementById(key)?.focus();
        return;
      }
    }
    if (!fields.is_anonymous && !fields.human_name) {
      showAlert('form-alert', 'Please enter your name, or check the Anonymous box.');
      nameInput.focus();
      return;
    }

    // Submit
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span> Recording…';
    statusEl.textContent = 'Analyzing intent with AI — this may take a moment.';

    try {
      const result = await postJSON(API.LOG, fields);

      if (result.success && result.id) {
        statusEl.textContent = 'Decision recorded. Redirecting…';
        window.location.href = `detail.html?id=${result.id}`;
      } else {
        throw new Error(result.error || 'An unexpected error occurred.');
      }
    } catch (err) {
      showAlert('form-alert', err.message || 'Network error. Please check your connection and try again.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Record Decision';
      statusEl.textContent = '';
    }
  });
})();
