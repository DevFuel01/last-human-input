// ============================================================
// LAST HUMAN INPUT — Decision Detail (detail.js)
// ============================================================

/**
 * Parse [SUMMARY], [ASSUMPTIONS], [RISKS] tags from a Gemini response.
 * Falls back to displaying the full text as a single block if tags are absent.
 */
function parseAiSections(text) {
  const extract = (tag) => {
    const re = new RegExp(`\\[${tag}\\]([\\s\\S]*?)\\[\/${tag}\\]`, 'i');
    const m  = text.match(re);
    return m ? m[1].trim() : null;
  };
  return {
    summary:     extract('SUMMARY'),
    assumptions: extract('ASSUMPTIONS'),
    risks:       extract('RISKS'),
    raw:         text,
  };
}

/**
 * Render the AI analysis into the #ai-section element.
 * Shows three distinct labeled sub-blocks when structured tags are present,
 * or falls back to a plain text paragraph for legacy summaries.
 */
function renderAiSections(text) {
  const section = document.getElementById('ai-section');
  if (!section) return;

  const p = parseAiSections(text);
  const hasStructure = p.summary && p.assumptions && p.risks;

  if (hasStructure) {
    section.innerHTML = `
      <h2>AI Intent Summary</h2>
      <div class="ai-label">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <circle cx="5" cy="5" r="4.5" stroke="currentColor"/>
          <path d="M5 3v2.5L6.5 7" stroke="currentColor" stroke-width="1" stroke-linecap="round"/>
        </svg>
        Gemini &middot; Neutral Analysis
      </div>
      <div class="ai-structured">
        <div class="ai-sub-block ai-sub-block--intent">
          <div class="ai-sub-label">Intent &amp; Goal</div>
          <p class="ai-sub-text">${esc(p.summary)}</p>
        </div>
        <div class="ai-sub-block ai-sub-block--assumptions">
          <div class="ai-sub-label">Assumptions</div>
          <p class="ai-sub-text">${esc(p.assumptions)}</p>
        </div>
        <div class="ai-sub-block ai-sub-block--risks">
          <div class="ai-sub-label">Ethical &amp; Social Risks</div>
          <p class="ai-sub-text">${esc(p.risks)}</p>
        </div>
      </div>
    `;
  } else {
    // Legacy / plain-text fallback (seed data)
    section.innerHTML = `
      <h2>AI Intent Summary</h2>
      <div class="ai-label">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
          <circle cx="5" cy="5" r="4.5" stroke="currentColor"/>
          <path d="M5 3v2.5L6.5 7" stroke="currentColor" stroke-width="1" stroke-linecap="round"/>
        </svg>
        Gemini &middot; Neutral Analysis
      </div>
      <p class="ai-summary-text">${esc(p.raw)}</p>
    `;
  }
}

// Calls generate_summary.php to fetch/create the AI summary
// for a decision that was just submitted (ai_summary is empty).
async function generateSummary(id) {
  try {
    const data = await getJSON(`api/generate_summary.php?id=${encodeURIComponent(id)}`);
    if (data.success && data.summary) {
      renderAiSections(data.summary);
      const pending = document.getElementById('ai-pending-msg');
      if (pending) pending.remove();
    }
  } catch (_) { /* silently skip if Gemini is unavailable */ }
}

(async function () {
  const container = document.getElementById('detail-container');
  const id = getParam('id');

  if (!id) {
    container.innerHTML = `<div class="state-box state-box--error">No decision ID specified. <a href="decisions.html">Return to archive</a>.</div>`;
    return;
  }

  try {
    const data = await getJSON(`${API.DETAIL}?id=${encodeURIComponent(id)}`);

    if (!data.success || !data.decision) {
      container.innerHTML = `<div class="state-box state-box--error">Decision not found. <a href="decisions.html">Return to archive</a>.</div>`;
      return;
    }

    const d = data.decision;
    const displayName = d.is_anonymous == 1 ? 'Anonymous' : esc(d.human_name || 'Unknown');
    const loggedDate  = formatDate(d.created_at);

    // Set page title
    document.title = `${d.title} — Last Human Input`;

    // ── AI Summary block ────────────────────────────────────
    // Built as a placeholder shell; renderAiSections() fills it in.
    const aiBlock = d.ai_summary
      ? `<div class="detail-section" id="ai-section"></div>` // filled by renderAiSections() after render
      : `<div class="detail-section" id="ai-section">
           <h2>AI Intent Summary</h2>
           <p id="ai-pending-msg" style="font-size:0.88rem;color:var(--ink-faint);display:flex;align-items:center;gap:0.6rem;">
             <span class="spinner"></span> Generating analysis&hellip;
           </p>
         </div>`;

    // ── Full HTML ───────────────────────────────────────────
    container.innerHTML = `
      <a href="decisions.html" class="back-link">&#8592; Archive</a>

      <!-- Header -->
      <div style="margin-bottom:2rem;">
        <p class="section-label">Decision Record</p>
        <h1 class="page-title" style="max-width:95%;">${esc(d.title)}</h1>
        <div style="display:flex; align-items:center; gap:0.85rem; margin-top:0.6rem; flex-wrap:wrap;">
          <span class="badge">${esc(d.domain)}</span>
          <span class="date-str">Logged ${loggedDate}</span>
          <span class="date-str">&middot;</span>
          <span class="date-str">By ${displayName}</span>
          <span class="date-str">&middot;</span>
          <span class="permanent-badge" title="This record cannot be modified after submission.">
            <svg width="9" height="11" viewBox="0 0 9 11" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align:middle;">
              <rect x="0.5" y="4.5" width="8" height="6" rx="1" stroke="currentColor"/>
              <path d="M2 4.5V3a2.5 2.5 0 0 1 5 0v1.5" stroke="currentColor" stroke-linecap="round"/>
            </svg>
            Permanent Record
          </span>
        </div>
      </div>

      <!-- Section 1: Human Input -->
      <div class="detail-section" id="human-section">
        <h2>Human Input</h2>

        <div class="field-block">
          <div class="field-label">What is being automated</div>
          <div class="field-value">${esc(d.automation_description)}</div>
        </div>

        <div class="field-block">
          <div class="field-label">Reason for automation &amp; goal</div>
          <div class="field-value">${esc(d.goal)}</div>
        </div>

        <div class="field-block">
          <div class="field-label">Assumptions made</div>
          <div class="field-value">${esc(d.assumptions)}</div>
        </div>

        <div class="field-block">
          <div class="field-label">Acknowledged risks &amp; uncertainties</div>
          <div class="field-value">${esc(d.risks)}</div>
        </div>
      </div>

      <!-- Section 2: AI Intent Summary -->
      ${aiBlock}

      <!-- Section 3: Timeline -->
      <div class="detail-section" id="timeline-section">
        <h2>Timeline</h2>
        <div class="timeline">

          <div class="timeline-item timeline-item--done">
            <div class="timeline-item__dot-col">
              <div class="timeline-item__dot"></div>
              <div class="timeline-item__line"></div>
            </div>
            <div class="timeline-item__body">
              <div class="timeline-item__step">Step 1 &middot; ${loggedDate}</div>
              <div class="timeline-item__title">Human decision recorded</div>
              <div class="timeline-item__desc">
                ${displayName} made the decision to automate. Intent, assumptions, and risks logged in this archive.
              </div>
            </div>
          </div>

          <div class="timeline-item timeline-item--done">
            <div class="timeline-item__dot-col">
              <div class="timeline-item__dot"></div>
              <div class="timeline-item__line"></div>
            </div>
            <div class="timeline-item__body">
              <div class="timeline-item__step">Step 2 &middot; Simulated</div>
              <div class="timeline-item__title">System deployed</div>
              <div class="timeline-item__desc">
                The automated system went live. From this point, the process operates without continuous human involvement.
              </div>
            </div>
          </div>

          <div class="timeline-item timeline-item--future">
            <div class="timeline-item__dot-col">
              <div class="timeline-item__dot"></div>
              <div class="timeline-item__line"></div>
            </div>
            <div class="timeline-item__body">
              <div class="timeline-item__step">Step 3 &middot; Future</div>
              <div class="timeline-item__title">Outcome — Unknown</div>
              <div class="timeline-item__desc">
                What this automation will affect, who it will impact, and whether it achieves its goal — is not yet known.
              </div>
            </div>
          </div>

        </div>

        <div class="closing-statement">
          "The future outcome is unknown. Responsibility begins here."
        </div>
      </div>

      <!-- Back -->
      <div style="margin-top:2rem;">
        <a href="decisions.html" class="btn btn--ghost">&#8592; Back to Archive</a>
      </div>
    `;

    // Render AI sections into the placeholder shell
    if (d.ai_summary) {
      renderAiSections(d.ai_summary);     // existing summary — parse & display
    } else {
      generateSummary(id);               // new entry — call Gemini then render
    }

  } catch (err) {
    container.innerHTML = `<div class="state-box state-box--error">Network error: ${esc(err.message)}<br><a href="decisions.html">Return to archive</a>.</div>`;
  }
})();
