<?php
// ============================================================
// LAST HUMAN INPUT — Gemini AI Integration Helper
// ============================================================

require_once __DIR__ . '/config.php';

/**
 * Sends the composed decision text to Gemini and returns
 * a neutral, factual 3-paragraph intent summary.
 */
function getGeminiSummary(string $decisionText): string
{
    $apiKey = GEMINI_API_KEY;

    if (empty($apiKey) || $apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
        return 'AI summary unavailable — no API key configured. Add your Gemini API key to config.php.';
    }

    $prompt = <<<PROMPT
You are an impartial analyst documenting human decisions that precede automation.
Your role is to act as a mirror, not a decision-maker.

Rules you must follow without exception:
- Write in neutral, factual language only
- Do not judge the decision
- Do not moralize or editorialize
- Do not make recommendations or suggest alternatives
- Do not exaggerate risks or outcomes
- Do not speculate beyond what is stated
- Do not use dramatic or emotionally charged language

Analyze the following decision and respond using EXACTLY this format with the tags included:

[SUMMARY]
Write 3 to 4 neutral sentences describing what the human is trying to achieve, the context, and the core goal.
[/SUMMARY]

[ASSUMPTIONS]
Write 2 to 4 sentences stating the beliefs or conditions the decision-maker is relying on being true. Include both stated and implicit assumptions.
[/ASSUMPTIONS]

[RISKS]
Write 2 to 4 sentences describing potential negative effects on people or groups affected by this automation. Factual only. No exaggeration.
[/RISKS]

Decision:
{$decisionText}

Use only plain sentences inside each section. No bullet points. No sub-headers. No markdown. No recommendations.
PROMPT;

    $url = GEMINI_API_ENDPOINT . '?key=' . $apiKey;
    $body = json_encode([
        'contents' => [
            ['parts' => [['text' => $prompt]]]
        ],
        'generationConfig' => [
            'temperature'     => 0.3,
            'maxOutputTokens' => 1500,
        ]
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 30,
    ]);

    $response = curl_exec($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        return 'AI summary unavailable — network error: ' . $curlError;
    }

    $data = json_decode($response, true);

    // Extract text from Gemini response
    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;

    if (!$text) {
        // Return the raw response for debugging if something unexpected happens
        $errorMsg = $data['error']['message'] ?? 'Unknown error';
        return 'AI summary unavailable — API error: ' . $errorMsg;
    }

    return trim($text);
}

/**
 * Composes a plain-text summary of all decision fields
 * to send as context to Gemini.
 */
function composeDecisionText(array $fields): string
{
    return implode("\n\n", [
        "Title: " . $fields['title'],
        "Domain: " . $fields['domain'],
        "What is being automated: " . $fields['automation_description'],
        "Reason / Goal: " . $fields['goal'],
        "Assumptions made: " . $fields['assumptions'],
        "Acknowledged risks: " . $fields['risks'],
    ]);
}
